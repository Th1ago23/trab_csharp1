﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Conversor
    {
      public float Converte_metro(float metro)
        {
            return metro * 1000;
        }
    }
}
