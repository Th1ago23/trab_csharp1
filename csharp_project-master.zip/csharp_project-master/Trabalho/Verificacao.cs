﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Classes
{
   
    public class Verificacao
    {
        public string Verifica_triangulo(float a, float b, float c)
        
        {
            bool prossiga = true;
            do {


                string confirma = string.Empty;
                float maior_num=0;
                float menor_num_b=-0;
                float menor_num_c=0;
                if (a >= b && a >= c)
                {
                    maior_num = a;
                    menor_num_b = b;
                    menor_num_c = c;

                }else if (b >= a && b >= c)
                {
                    maior_num = b;
                    menor_num_b = a;
                    menor_num_c = c;
                }else if(c >= a && c >= b)
                {
                    maior_num = c;
                    menor_num_b = b;
                    menor_num_c = a;
                }
                

                if(maior_num < (menor_num_b + menor_num_c) && maior_num > 0 && menor_num_b > 0 && menor_num_c > 0)
                {
                   
                    Console.WriteLine("Essas medidas formam um triângulo");

                    
                    if (maior_num == menor_num_b && maior_num == menor_num_b)
                    {
                        confirma = "Esse triângulo é equilátero";
                    }
                    else
                    {
                        confirma = "Esse triângulo não é equilátero";
                    }
                    return confirma;
                }
                else
                {
                    confirma = "Essas medidas não formam um triângulo";
                    return confirma;
                }

                //||

            } while (prossiga);
        }
    }
    }


