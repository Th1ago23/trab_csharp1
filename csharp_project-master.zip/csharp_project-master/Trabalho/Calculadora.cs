﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Calculadora
    {
        public int Soma(int item_a, int item_b)
        {
            return item_a + item_b;
        }

    
    }
}
